/*
 * Question: Small social network with connections
 *   A-B, A-C, B-D, B-E, C-F, E-F
 *
 * a) Implement the network using an Adjacency Matrix and an Adjacency List.
 *    Perform BFS and DFS starting from vertex A on both representations.
 * b) Implement a search operation to locate a specified vertex using the two
 *    representations. Record the operations (comparisons) required.
 * c) (analysis only - see docs/) compare space, traversal behaviour,
 *    search/edge-checking operations and time complexity.
 *
 * Compile: gcc graph_representations.c -o graph_representations
 * Run:     ./graph_representations
 */

#include <stdio.h>
#include <stdlib.h>

#define V 6   /* number of vertices: A,B,C,D,E,F */
#define E 6   /* number of edges */

char labels[V] = {'A', 'B', 'C', 'D', 'E', 'F'};

/* ---------------- Adjacency Matrix ---------------- */
int adjMatrix[V][V];

/* ---------------- Adjacency List ---------------- */
typedef struct Node {
    int vertex;
    struct Node *next;
} Node;

Node *adjList[V];

/* edges given in the question, as index pairs (A=0,B=1,C=2,D=3,E=4,F=5) */
int edges[E][2] = {
    {0, 1},  /* A-B */
    {0, 2},  /* A-C */
    {1, 3},  /* B-D */
    {1, 4},  /* B-E */
    {2, 5},  /* C-F */
    {4, 5}   /* E-F */
};

void listAppend(int u, int v) {
    Node *n = (Node *)malloc(sizeof(Node));
    n->vertex = v;
    n->next = NULL;
    if (adjList[u] == NULL) {
        adjList[u] = n;
    } else {
        Node *cur = adjList[u];
        while (cur->next != NULL) cur = cur->next;
        cur->next = n;
    }
}

void buildGraph(void) {
    for (int i = 0; i < V; i++) adjList[i] = NULL;
    for (int i = 0; i < V; i++)
        for (int j = 0; j < V; j++)
            adjMatrix[i][j] = 0;

    for (int e = 0; e < E; e++) {
        int u = edges[e][0], v = edges[e][1];
        adjMatrix[u][v] = 1;
        adjMatrix[v][u] = 1;
        listAppend(u, v);
        listAppend(v, u);
    }
}

void printMatrix(void) {
    printf("     ");
    for (int i = 0; i < V; i++) printf("%c ", labels[i]);
    printf("\n");
    for (int i = 0; i < V; i++) {
        printf("  %c  ", labels[i]);
        for (int j = 0; j < V; j++) printf("%d ", adjMatrix[i][j]);
        printf("\n");
    }
}

void printList(void) {
    for (int i = 0; i < V; i++) {
        printf("  %c -> ", labels[i]);
        Node *cur = adjList[i];
        while (cur != NULL) {
            printf("%c", labels[cur->vertex]);
            if (cur->next != NULL) printf(" -> ");
            cur = cur->next;
        }
        printf("\n");
    }
}

/* ---------------- BFS (Adjacency Matrix) ---------------- */
void bfsMatrix(int start, int *opCount) {
    int visited[V] = {0};
    int queue[V], front = 0, rear = 0;
    int ops = 0;

    visited[start] = 1;
    queue[rear++] = start;

    printf("BFS (matrix) order: ");
    while (front < rear) {
        int u = queue[front++];
        printf("%c ", labels[u]);
        for (int v = 0; v < V; v++) {
            ops++;                          /* one matrix-cell check per candidate neighbour */
            if (adjMatrix[u][v] == 1 && !visited[v]) {
                visited[v] = 1;
                queue[rear++] = v;
            }
        }
    }
    printf("\n");
    *opCount = ops;
}

/* ---------------- BFS (Adjacency List) ---------------- */
void bfsList(int start, int *opCount) {
    int visited[V] = {0};
    int queue[V], front = 0, rear = 0;
    int ops = 0;

    visited[start] = 1;
    queue[rear++] = start;

    printf("BFS (list)   order: ");
    while (front < rear) {
        int u = queue[front++];
        printf("%c ", labels[u]);
        Node *cur = adjList[u];
        while (cur != NULL) {
            ops++;                          /* one list-node visit per neighbour entry */
            int v = cur->vertex;
            if (!visited[v]) {
                visited[v] = 1;
                queue[rear++] = v;
            }
            cur = cur->next;
        }
    }
    printf("\n");
    *opCount = ops;
}

/* ---------------- DFS (Adjacency Matrix) ---------------- */
void dfsMatrixHelper(int u, int visited[], int *ops) {
    visited[u] = 1;
    printf("%c ", labels[u]);
    for (int v = 0; v < V; v++) {
        (*ops)++;                           /* one matrix-cell check per candidate neighbour */
        if (adjMatrix[u][v] == 1 && !visited[v]) {
            dfsMatrixHelper(v, visited, ops);
        }
    }
}

void dfsMatrix(int start, int *opCount) {
    int visited[V] = {0};
    int ops = 0;
    printf("DFS (matrix) order: ");
    dfsMatrixHelper(start, visited, &ops);
    printf("\n");
    *opCount = ops;
}

/* ---------------- DFS (Adjacency List) ---------------- */
void dfsListHelper(int u, int visited[], int *ops) {
    visited[u] = 1;
    printf("%c ", labels[u]);
    Node *cur = adjList[u];
    while (cur != NULL) {
        (*ops)++;                           /* one list-node visit per neighbour entry */
        int v = cur->vertex;
        if (!visited[v]) {
            dfsListHelper(v, visited, ops);
        }
        cur = cur->next;
    }
}

void dfsList(int start, int *opCount) {
    int visited[V] = {0};
    int ops = 0;
    printf("DFS (list)   order: ");
    dfsListHelper(start, visited, &ops);
    printf("\n");
    *opCount = ops;
}

/* ---------------- b) Search operations ---------------- */

/* Locate a vertex by label - identical linear scan for both representations,
 * since the vertex set itself (labels[]) is stored the same way regardless
 * of which structure is used for the EDGES. */
int locateVertex(char target, int *cmpCount) {
    int cmp = 0;
    for (int i = 0; i < V; i++) {
        cmp++;
        if (labels[i] == target) {
            *cmpCount = cmp;
            return i;
        }
    }
    *cmpCount = cmp;
    return -1;
}

/* Edge-existence search: Adjacency Matrix -> direct index, O(1) */
int edgeExistsMatrix(int u, int v, int *opCount) {
    *opCount = 1;                            /* single direct lookup */
    return adjMatrix[u][v];
}

/* Edge-existence search: Adjacency List -> walk u's list until v found/end */
int edgeExistsList(int u, int v, int *opCount) {
    int ops = 0;
    Node *cur = adjList[u];
    while (cur != NULL) {
        ops++;
        if (cur->vertex == v) {
            *opCount = ops;
            return 1;
        }
        cur = cur->next;
    }
    *opCount = ops;
    return 0;
}

int main(void) {
    buildGraph();

    printf("Vertices: A B C D E F\n");
    printf("Edges   : A-B, A-C, B-D, B-E, C-F, E-F\n\n");

    printf("=== a) Adjacency Matrix ===\n");
    printMatrix();
    printf("\n=== a) Adjacency List ===\n");
    printList();

    printf("\n=== a) BFS from A ===\n");
    int bfsMOps, bfsLOps;
    bfsMatrix(0, &bfsMOps);
    bfsList(0, &bfsLOps);
    printf("  Matrix cell-checks used : %d\n", bfsMOps);
    printf("  List node-visits used   : %d\n", bfsLOps);

    printf("\n=== a) DFS from A ===\n");
    int dfsMOps, dfsLOps;
    dfsMatrix(0, &dfsMOps);
    dfsList(0, &dfsLOps);
    printf("  Matrix cell-checks used : %d\n", dfsMOps);
    printf("  List node-visits used   : %d\n", dfsLOps);

    printf("\n=== b) Search operation: locate vertex 'E' ===\n");
    int cmp;
    int idx = locateVertex('E', &cmp);
    printf("  Found '%c' at index %d, comparisons used = %d (same for both\n"
           "  representations - the vertex set itself is stored identically)\n",
           labels[idx], idx, cmp);

    printf("\n=== b) Search operation: does edge D-F exist? (not connected) ===\n");
    int opM1, opL1;
    int rM1 = edgeExistsMatrix(3, 5, &opM1);
    int rL1 = edgeExistsList(3, 5, &opL1);
    printf("  Matrix -> result = %s, operations used = %d\n", rM1 ? "YES" : "NO", opM1);
    printf("  List   -> result = %s, operations used = %d\n", rL1 ? "YES" : "NO", opL1);

    printf("\n=== b) Search operation: does edge B-E exist? (connected) ===\n");
    int opM2, opL2;
    int rM2 = edgeExistsMatrix(1, 4, &opM2);
    int rL2 = edgeExistsList(1, 4, &opL2);
    printf("  Matrix -> result = %s, operations used = %d\n", rM2 ? "YES" : "NO", opM2);
    printf("  List   -> result = %s, operations used = %d\n", rL2 ? "YES" : "NO", opL2);

    printf("\n=== Summary of operation counts ===\n");
    printf("  %-30s %10s %10s\n", "Operation", "Matrix", "List");
    printf("  %-30s %10d %10d\n", "BFS traversal from A", bfsMOps, bfsLOps);
    printf("  %-30s %10d %10d\n", "DFS traversal from A", dfsMOps, dfsLOps);
    printf("  %-30s %10d %10d\n", "Edge search D-F (absent)", opM1, opL1);
    printf("  %-30s %10d %10d\n", "Edge search B-E (present)", opM2, opL2);

    return 0;
}
