# Social Network Graph — Adjacency Matrix vs Adjacency List

**Network:** vertices A, B, C, D, E, F
**Connections:** A-B, A-C, B-D, B-E, C-F, E-F

This repo contains everything required by the assignment:

| Requirement | File |
|---|---|
| Source code | [`src/graph_representations.c`](src/graph_representations.c) |
| Input data | [`input/input.txt`](input/input.txt) |
| Output | [`output/output.txt`](output/output.txt) |
| Trace table | [`docs/trace_table.md`](docs/trace_table.md) |
| Complexity analysis | [`docs/complexity_analysis.md`](docs/complexity_analysis.md) |
| Comparison table | [`docs/comparison_table.md`](docs/comparison_table.md) |
| Final conclusion | [`docs/conclusion.md`](docs/conclusion.md) |

## What the program does

1. **(a)** Builds the network as both an **Adjacency Matrix** and an
   **Adjacency List**, prints both, then runs **BFS** and **DFS** from
   vertex `A` on each representation, counting the low-level operations
   used (matrix cell-checks vs. adjacency-list node-visits).
2. **(b)** Implements two kinds of search and counts the comparisons/checks
   each needs:
   - **Locate a vertex** by label (`E`) — identical linear scan for both
     representations.
   - **Edge-existence search** for a disconnected pair (`D-F`) and a
     connected pair (`B-E`) — a single O(1) lookup on the matrix vs. a
     list walk of length up to `degree(u)`.
3. **(c)** — see `docs/` for the full space, traversal, search, and
   time-complexity analysis, and the final recommendation.

## How to run

```bash
cd src
gcc graph_representations.c -o graph_representations
./graph_representations
```

## Folder structure

```
.
├── src/
│   └── graph_representations.c
├── input/
│   └── input.txt
├── output/
│   └── output.txt
├── docs/
│   ├── trace_table.md
│   ├── complexity_analysis.md
│   ├── comparison_table.md
│   └── conclusion.md
└── README.md
```

## Result summary

| Metric | Adjacency Matrix | Adjacency List |
|---|---|---|
| BFS order from A | A B C D E F | A B C D E F |
| DFS order from A | A B D E F C | A B D E F C |
| BFS/DFS operations used | 36 | **12** |
| Space (this network) | 36 cells | **18 units** |
| Locate vertex 'E' (comparisons) | 5 | 5 |
| Edge search D-F (absent) | 1 op | 1 op |
| Edge search B-E (present) | **1 op** | 3 ops |
| Space complexity | O(V²) | **O(V + E)** |
| Traversal time complexity | O(V²) | **O(V + E)** |
| Edge-check time complexity | **O(1)** | O(degree(u)) |

**Conclusion:** the **Adjacency List** is the more suitable representation
for this *sparse* social network — it matches the matrix's traversal
correctness while using a third of the operations and roughly half the
storage, only giving up the matrix's constant-time single edge lookup. See
[`docs/conclusion.md`](docs/conclusion.md) for full justification.
