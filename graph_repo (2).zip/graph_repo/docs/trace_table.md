# Trace Tables

**Vertices:** A, B, C, D, E, F
**Edges:** A-B, A-C, B-D, B-E, C-F, E-F

Adjacency list order used throughout (matches alphabetical/insertion order,
so both representations traverse neighbours in the same sequence):

| Vertex | Neighbours |
|---|---|
| A | B, C |
| B | A, D, E |
| C | A, F |
| D | B |
| E | B, F |
| F | C, E |

## 1) BFS from A

### Adjacency Matrix (row scan, 6 cell-checks per dequeued vertex)

| Step | Dequeue | Cells checked (A..F) | Newly enqueued | Cell-checks this step | Running total |
|---|---|---|---|---|---|
| 1 | A | 0,1,1,0,0,0 | B, C | 6 | 6 |
| 2 | B | 1,0,0,1,1,0 | D, E | 6 | 12 |
| 3 | C | 1,0,0,0,0,1 | F | 6 | 18 |
| 4 | D | 0,1,0,0,0,0 | — | 6 | 24 |
| 5 | E | 0,1,0,0,0,1 | — | 6 | 30 |
| 6 | F | 0,0,1,0,1,0 | — | 6 | 36 |

**BFS order (matrix):** A, B, C, D, E, F
**Total matrix cell-checks: 36** (= 6 vertices x 6 columns, every row scanned fully)

### Adjacency List (walk only the actual neighbour nodes)

| Step | Dequeue | List walked | Newly enqueued | Node-visits this step | Running total |
|---|---|---|---|---|---|
| 1 | A | B, C | B, C | 2 | 2 |
| 2 | B | A, D, E | D, E | 3 | 5 |
| 3 | C | A, F | F | 2 | 7 |
| 4 | D | B | — | 1 | 8 |
| 5 | E | B, F | — | 2 | 10 |
| 6 | F | C, E | — | 2 | 12 |

**BFS order (list):** A, B, C, D, E, F (identical order to the matrix run)
**Total list node-visits: 12** (= 2 x |E|, each of the 6 edges walked from both ends)

## 2) DFS from A (recursive, first-unvisited-neighbour-first)

Both representations explore neighbours in the same order (B before C at A,
D before E at B, etc.), so both produce the same DFS order:

| Step | Visit | Reason |
|---|---|---|
| 1 | A | start |
| 2 | B | first unvisited neighbour of A |
| 3 | D | first unvisited neighbour of B |
| 4 | E | backtrack to B, next unvisited neighbour |
| 5 | F | unvisited neighbour of E |
| 6 | C | backtrack to F, unvisited neighbour (A already visited) |

**DFS order (matrix and list): A, B, D, E, F, C**

Operation counts behave exactly as in BFS, because every visited vertex still
scans its full matrix row (6 cells) or walks its full adjacency list once:

| | Matrix cell-checks | List node-visits |
|---|---|---|
| Total for DFS from A | **36** | **12** |

## 3) Search operation — locate vertex 'E'

The vertex set itself (`labels[] = {A,B,C,D,E,F}`) is stored the same way
regardless of which structure holds the *edges*, so this search is identical
for both representations: a linear scan of the label array.

| Step | Compare label[i] to 'E' | Match? | Comparisons so far |
|---|---|---|---|
| 1 | 'A' == 'E'? | no | 1 |
| 2 | 'B' == 'E'? | no | 2 |
| 3 | 'C' == 'E'? | no | 3 |
| 4 | 'D' == 'E'? | no | 4 |
| 5 | 'E' == 'E'? | yes | 5 |

**Result: found at index 4, comparisons = 5** (same for matrix-based and
list-based graphs, since it does not touch the edge structure at all).

## 4) Search operation — does an edge exist?

### Query 1: D-F (not connected)

| Representation | Operation | Comparisons/checks |
|---|---|---|
| Matrix | direct lookup `adjMatrix[D][F]` | 1 |
| List | walk D's list `[B]`, compare each entry to F | 1 (list of length 1, no match) |

Result: **NO** (both agree)

### Query 2: B-E (connected)

| Representation | Operation | Comparisons/checks |
|---|---|---|
| Matrix | direct lookup `adjMatrix[B][E]` | 1 |
| List | walk B's list `[A, D, E]`: A≠E, D≠E, E=E -> stop | 3 |

Result: **YES** (both agree, but the list needed 3 comparisons vs the
matrix's constant 1)
