# Final Conclusion

Both representations correctly reproduce the same network and the same
traversal orders for the given data:

- **BFS from A:** A, B, C, D, E, F (both representations)
- **DFS from A:** A, B, D, E, F, C (both representations)

They differ sharply, however, in how much *work* and *space* are needed to
get those identical results.

## Behaviour under the three areas asked for

1. **Space requirements:**
   The adjacency matrix always allocates V² cells (36 here), no matter how
   many edges actually exist. The adjacency list allocates only
   O(V + E) units (18 here) — proportional to the real data. For this
   6-vertex, 6-edge network, the matrix uses **exactly twice** the storage
   of the list, and that gap grows quadratically as the network scales up.

2. **Traversal behaviour:**
   Both BFS and DFS visit vertices in the same order regardless of
   representation, because both scan each vertex's neighbours in the same
   (alphabetical / insertion) order. But the *cost* of finding those
   neighbours differs: the matrix must check all 6 possible columns for
   every vertex (36 checks total), while the list only ever walks the
   neighbours that actually exist (12 node-visits total — exactly 2 x |E|).

3. **Search / edge-checking operations:**
   Locating a vertex by label is identical for both (5 comparisons to find
   'E'), since the vertex set itself isn't affected by the edge
   representation. But checking whether a specific edge exists is where the
   matrix shines: `adjMatrix[u][v]` is a single O(1) lookup every time (1
   operation for both the D-F and B-E queries), whereas the list must walk
   the source vertex's neighbour chain — cheap for a low-degree vertex like
   D (1 operation), but growing with degree(u) (3 operations for B, which
   has 3 neighbours).

## Recommendation

**The Adjacency List is the more suitable representation for this sparse
social network**, because:

- Real social networks are sparse — most people know a small, roughly
  constant number of other people, so E grows close to linearly with V, not
  quadratically. The list's O(V + E) space and traversal cost track that
  reality, while the matrix's O(V²) cost wastes space and time on the
  overwhelming majority of "no relationship" pairs (24 of the 36 cells here
  are unused zeros).
- BFS/DFS — the operations a social network needs most often (friend
  suggestions, shortest connection path, community detection) — are
  measurably cheaper on the list (12 operations vs 36 in this run), and that
  gap widens as the network grows.
- The only case where the matrix wins is a single, isolated "are these two
  people connected?" query (O(1) vs O(degree(u))). That advantage matters
  for a dense graph or for an application dominated by repeated edge
  lookups, but it does not outweigh the list's space and traversal savings
  for a sparse, traversal-heavy social network.

**Justification (from the execution results above):** the list matched the
matrix's traversal correctness while using exactly **one-third** the
operations (12 vs 36) and roughly **half** the storage (18 vs 36 units),
at the cost of a slightly more expensive edge-existence check only for
higher-degree vertices (3 vs 1 operations for B-E). For a sparse network,
that trade-off clearly favours the **Adjacency List**.
