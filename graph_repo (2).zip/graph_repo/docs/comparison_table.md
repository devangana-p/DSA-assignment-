# Comparison: Adjacency Matrix vs Adjacency List

## Execution results on the given network (A-B, A-C, B-D, B-E, C-F, E-F)

| Criterion | Adjacency Matrix | Adjacency List |
|---|---|---|
| Storage used for 6 vertices / 6 edges | 36 cells (24 of them zero/unused) | 6 list-heads + 12 nodes = 18 units |
| BFS order from A | A, B, C, D, E, F | A, B, C, D, E, F (identical) |
| BFS operations (cell-checks / node-visits) | **36** | **12** |
| DFS order from A | A, B, D, E, F, C | A, B, D, E, F, C (identical) |
| DFS operations (cell-checks / node-visits) | **36** | **12** |
| Locate vertex 'E' (comparisons) | 5 | 5 (identical — vertex set stored the same way) |
| Edge search D-F (absent) — operations | 1 | 1 |
| Edge search B-E (present) — operations | **1** | 3 |
| Space complexity | O(V²) | O(V + E) |
| Traversal time complexity | O(V²) | O(V + E) |
| Edge-check time complexity | **O(1)** | O(degree(u)) |
| Best at | Fast, constant-time single edge lookups | Efficient traversal & storage on sparse graphs |

## Trend as the network grows (assuming it stays sparse, E ≈ V)

| V (members) | Matrix space (V²) | List space (V + 2E) | Matrix traversal ops | List traversal ops |
|---|---|---|---|---|
| 6 | 36 | 18 | 36 | 12 |
| 100 | 10,000 | ~300 | 10,000 | ~300 |
| 10,000 | 100,000,000 | ~30,000 | 100,000,000 | ~30,000 |

As the number of members grows while the graph stays sparse, the matrix's
space and traversal cost explode quadratically, while the list's cost
grows only linearly with the real amount of data (vertices + edges). The
matrix's single advantage — O(1) edge-existence checks — stays constant,
but does not offset the traversal and storage cost at scale.
