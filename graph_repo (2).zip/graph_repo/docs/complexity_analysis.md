# Complexity Analysis

Let **V** = number of vertices, **E** = number of edges.
For this network: V = 6, E = 6 (sparse: E is close to V, far below the
maximum possible V(V-1)/2 = 15 edges for 6 vertices).

## Adjacency Matrix

- **Storage:** a V x V array -> **O(V²) space**, regardless of how many
  edges actually exist. Here that is 36 cells to store 6 edges (12 marked
  entries, since each edge sets two symmetric cells) — most of the matrix
  (24 cells) is wasted zeros.
- **Building the graph:** each of the E edges sets 2 cells -> **O(E) time**
  to build, but the array itself must first be allocated/initialised at
  **O(V²)**.
- **BFS/DFS traversal:** to find the neighbours of a vertex, every column of
  its row must be scanned -> **O(V) per vertex**, so a full traversal is
  **O(V²) time** overall (36 cell-checks measured for this 6-vertex graph).
- **Edge existence check (search) `adjMatrix[u][v]`:** a single array
  index -> **O(1) time** (measured: 1 operation for every query, whether the
  edge exists or not).
- **Locate a vertex by label:** identical to the list version — a linear
  scan of the label array -> **O(V)** (measured: 5 comparisons to find 'E').

## Adjacency List

- **Storage:** one linked list per vertex holding only its actual
  neighbours -> **O(V + E) space**. Here that is 6 list-heads plus 12 nodes
  (2 per edge) = 18 units of storage, versus the matrix's 36 cells.
- **Building the graph:** each of the E edges appends 2 nodes ->
  **O(E) time** (no wasted allocation for non-edges).
- **BFS/DFS traversal:** each vertex's list holds exactly `degree(vertex)`
  nodes, so the total work across the whole traversal is
  **O(V + E) time** (measured: 12 node-visits = 2E, exactly matching every
  edge being walked once from each end).
- **Edge existence check (search):** must walk the source vertex's list
  until the target is found or the list ends -> **O(degree(u))**, i.e.
  worst case **O(V)** for a densely-connected vertex, but typically much
  cheaper on a sparse graph (measured: 1 operation for D→F, 3 operations
  for B→E, versus the matrix's constant 1 each time).
- **Locate a vertex by label:** same **O(V)** linear scan as the matrix
  version — this operation does not depend on the edge representation.

## Summary

| Operation | Adjacency Matrix | Adjacency List |
|---|---|---|
| Space | O(V²) | O(V + E) |
| Build graph | O(E) (+ O(V²) init) | O(E) |
| BFS / DFS traversal | O(V²) | O(V + E) |
| Edge existence check | **O(1)** | O(degree(u)) (worst case O(V)) |
| Locate vertex by label | O(V) | O(V) |

## Why the gap widens as the network grows

For a **sparse** social network (most people are connected to only a
handful of others, so E grows roughly linearly with V rather than
quadratically), the matrix's O(V²) space and traversal cost become
increasingly wasteful, while the list's O(V + E) cost tracks the actual
amount of real data:

| V (members) | Matrix cells (V²) | List units (V + 2E), assuming E ≈ V | Matrix "wasted" cells |
|---|---|---|---|
| 6 | 36 | 18 | 24 |
| 100 | 10,000 | ~300 | ~9,700 |
| 10,000 | 100,000,000 | ~30,000 | ~99,970,000 |

The only place the matrix wins outright is a single edge-existence check,
which stays O(1) no matter how large the network gets — the list's
O(degree(u)) can approach O(V) for a hub vertex with many connections, but
stays small for typical members in a sparse graph.
